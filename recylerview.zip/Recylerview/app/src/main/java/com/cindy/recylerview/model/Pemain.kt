package com.cindy.recylerview.model

data class Pemain(
    var nama : String,
    var foto : Int,
    var posisi : String,
    var tinggi : String,
    var tempatlahir : String,
    var tgllahir : String
)

